import pygame
import sys
import tensorflow as tf
import numpy as np

model = tf.saved_model.load('model')

#PARAMETERS

CELL_SIZE = 20

BG_COLOR = (0, 0, 0)
Tick_Speed = 120

pygame.init()

screen = pygame.display.set_mode((28*CELL_SIZE + 100, 28*CELL_SIZE + 75))
timer = pygame.time.Clock()
game_on = True

#VARIABLES
Cell_memory = [0 for i in range(28*28)]
Cell_memory_model = [0 for j in range(28*28)]

Guested_number = 0

N = 0
Grid = False
Draw = False
Variance_activation = False
bouton_gauche_enfonce = False
# Position et taille du bouton Reset
button_position = (CELL_SIZE*28 -20, CELL_SIZE*28 + 10)
button_size = (100, 50)

#FONCTIONS
def Correct_variance():
    global Cell_memory
    global N

    N += 1
    if Variance_activation and N > 300:
        v_variance = 0
        h_variance = 0

        # Compute the variance of the active cell
        for i in range(28 * 28):
            if Cell_memory[i] == 1:
                h_variance += abs(13.5 - i % 28) / Cell_memory.count(1)
                v_variance += abs(13.5 - i // 28) / Cell_memory.count(1)

        #The average variance of the dataset is 8.8
        hdelta_V = 8.8 - h_variance
        vdelta_V = 8.8 - v_variance

        new_cell = []
        for i in range(28 * 28):
            if Cell_memory[i] == 1:
                # Store the index of the new active cell
                new_cell.append(i + int(i*hdelta_V) + 28*int(i*vdelta_V))

        for i in range(28 * 28):
            if i in new_cell:
                Cell_memory_model[i] = 1



def Correct_bias():
    global N
    global Cell_memory_model

    Cell_memory_model = [0 for i in range(28*28)]

    global Cell_memory
    vertical_bias = 0
    horizontal_bias = 0
    
    #Compute the vertical bias and the horizontal bias    
    for i in range(28*28):
        if Cell_memory[i] == 1:
            horizontal_bias += (13.5 - i%28) / Cell_memory.count(1)
            vertical_bias += (13.5 - i//28) / Cell_memory.count(1)
            
      #Add the vertical bias and the horizontal bias to all coordonnate
    new_cell = []
    for i in range(28*28):
        if Cell_memory[i] == 1:
            
            # Store the index of the new active cell           
            new_cell.append(i + int(horizontal_bias + 1) + 28*int(vertical_bias + 1))

    for i in range (28*28):
        if i in new_cell:
            Cell_memory_model[i] = 1


def draw_button(screen, text, position, size):
    font = pygame.font.Font(None, 32)
    text_render = font.render(text, True, (0,0,0))
    x, y = position
    width, height = size
    pygame.draw.rect(screen, (200, 0, 0), (x, y, width, height))
    screen.blit(text_render, (x + 10, y + 10))


def Find_number(Model):

    image_array = np.array(Cell_memory_model).reshape((1, 28, 28, 1))
    image_array = image_array.astype(np.float32)
    output = Model(image_array)*100

    return np.round(output, decimals=0)

def Draw_BG():
    rect = pygame.Rect(0, 0, 28*CELL_SIZE, 28*CELL_SIZE)
    pygame.draw.rect(screen, pygame.Color(BG_COLOR), rect)
def Draw_cell(Cell_memory):
    CM = Cell_memory
    for i in range(28*28):
        if CM[i] == 1:
            rect = pygame.Rect((i%28)*CELL_SIZE, (i//28)*CELL_SIZE,CELL_SIZE, CELL_SIZE)
            pygame.draw.rect(screen, pygame.Color(255, 255, 255), rect)
def Draw_model_vision(Cell_memory_model):
    CMM = Cell_memory_model
    for i in range(28*28):
        if CMM[i] == 1:
            rect = pygame.Rect((i % 28) * CELL_SIZE, (i // 28) * CELL_SIZE, CELL_SIZE, CELL_SIZE)
            pygame.draw.rect(screen, pygame.Color(0,0,255 ), rect)


def Draw_number():
    if bouton_gauche_enfonce:
        mouse_x, mouse_y = pygame.mouse.get_pos()
        if mouse_y < CELL_SIZE*28 and mouse_x < CELL_SIZE*28 :
            n = int(mouse_y/CELL_SIZE)*28 + int(mouse_x/CELL_SIZE)
            Cell_memory[n] = 1

def Draw_grid():
    if Grid:
        for i in range(29):
            pygame.draw.line(screen, (200, 200, 200), (0, i*CELL_SIZE), (CELL_SIZE*28, i*CELL_SIZE))
            pygame.draw.line(screen, (200, 200, 200), (i*CELL_SIZE, 0), (i*CELL_SIZE, CELL_SIZE*28))
def draw_stat():

    Seperation = CELL_SIZE*2.5

    font = pygame.font.Font(None, 40)

    # Hiding the previous text
    rect = pygame.Rect(CELL_SIZE*28, 0 , CELL_SIZE*28, CELL_SIZE*28)
    pygame.draw.rect(screen, pygame.Color(0,0,0), rect)

    rect = pygame.Rect(0, CELL_SIZE * 28, CELL_SIZE * 28, CELL_SIZE * 28)
    pygame.draw.rect(screen, pygame.Color(0, 0, 0), rect)

    # Show the stat
    for i in range(10):
        text_surface = font.render(f"{i}:{int(Guested_number[0][i])}%", True, (255, 255, 255))
        screen.blit(text_surface, (CELL_SIZE*28 + 10, 10 + i*Seperation))

    # Show the guessed number
    text_surface = font.render(f"Number : {np.argmax(Guested_number)} ({Guested_number[0][np.argmax(Guested_number)]})%", True, (255, 255, 255))
    screen.blit(text_surface, (10, CELL_SIZE*28 + 30))

while game_on :
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        elif event.type == pygame.KEYDOWN:  # Vérifier si une touche est enfoncée
            if event.key == pygame.K_g:  # Check if g is touch
                if Grid :
                    Grid = False
                else : Grid = True


            if event.key == pygame.K_v:  # Vérifier si la touche enfoncée est la barre d'espace
                if Variance_activation :
                    Variance_activation = False
                else : Variance_activation = True



            if event.key == pygame.K_d:
                if Draw :
                    Draw = False
                else : Draw = True



        elif event.type == pygame.MOUSEBUTTONDOWN:

            # Détecter le clic gauche (bouton 1)

            if event.button == 1:
                bouton_gauche_enfonce = True

            # Vérifier si le clic est sur le bouton
            mouse_x, mouse_y = event.pos
            button_x, button_y = button_position
            button_width, button_height = button_size

            if button_x <= mouse_x <= button_x + button_width and button_y <= mouse_y <= button_y + button_height:
                    Cell_memory = [0 for i in range(28 * 28)]

        elif event.type == pygame.MOUSEBUTTONUP:

            # Détecter le relâchement du clic gauche (bouton 1)

            if event.button == 1:
                bouton_gauche_enfonce = False

    Correct_bias()
    Correct_variance()
    Guested_number = Find_number(model)

    Draw_BG()
    Draw_cell(Cell_memory)
    #Draw_model_vision(Cell_memory_model)




    Draw_number()



    draw_stat()
    draw_button(screen, "RESET", button_position, button_size)
    Draw_grid()

    pygame.display.update()
    timer.tick(Tick_Speed)